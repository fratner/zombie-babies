import pygame
import src.toolbox as toolbox
import src.database as database
import src.textbox as textbox
import sys
import os

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)


class HUD():

    def getImage(self, file):
        if file in self.images:
            return self.images.get(file)
        else:
            self.images[file] = pygame.image.load(file)
            return self.images.get(file)

    
    def __init__(self, screen, player):
        self.images = {}
        self.screen = screen
        self.player = player
        self.state = 'selection'
        self.hud_font = pygame.font.SysFont('Impact', 20)
        self.hUd_font = pygame.font.SysFont('Impact', 25)
        self.gameover_font = pygame.font.SysFont('Impact', 80)
        self.controls_font = pygame.font.SysFont('Impact', 50)
        self.credit_font = pygame.font.SysFont('default', 20)
        self.bigger_font = pygame.font.SysFont('Impact', 30)
        self.lvl_font = pygame.font.SysFont('Impact', 45)
        self.score_text = self.hud_font.render("Cheat Code: uuddlrlrba", True, (255, 255, 255))
        self.texttext = self.hUd_font.render("Input your Name here. Maximum is 20 Characters.", True, (255, 255, 255))
        self.level_number = 1
        self.air = self.getImage(resource_path("assets/air.png"))
        self.highscorefile = open(resource_path("src/highscorefile.txt"), "r")
        self.highscore = (self.highscorefile.read())
        self.input_box = textbox.InputBox(550, 200, 140, 32)
        self.oo = False
        self.garfield = self.getImage(resource_path("char/MomS.png"))
        self.dad = self.getImage(resource_path("char/DadS.png"))
        self.E = self.getImage(resource_path("assets/yelrect.png"))
        
        self.hsBG = self.getImage(resource_path("assets/leaderboard_BG.png"))
        if (self.highscore):
            self.highscore = int(self.highscore)
        else:
            self.highscore = 0
        self.highscorefile.close()
        self.hstxt = ""
 

        self.title_image = self.getImage(resource_path("assets/Title.png"))
        self.select_image = self.getImage(resource_path("assets/CharacterSelectMenu.png"))
        self.start_text = self.bigger_font.render("Press any key to start", True, (255, 255, 255))
        self.tutor_text = self.credit_font.render("Controls: WASD to Move - Left Click to shoot - Right Click for Barrel - E for Crate", True, (255, 255, 255))
        self.credits = self.credit_font.render("Credits: Characters - Maxchills1337 - Backgrounds - Daphnetrevelin - Directing and Coding - Felix Ratner", True, (255, 255, 255))
        self.lvlpop = self.lvl_font.render("You have reached Level " + str(self.level_number), True, (251, 255, 0))
        self.blink_timer_max = 80
        self.blink_timer = self.blink_timer_max
        self.lvltimer_max = 200
        self.lvltimer = self.lvltimer_max

        self.gameover_text = self.gameover_font.render("Game Over", True, (255, 255, 255))
        self.reset_button = self.getImage(resource_path("assets/BtnReset.png"))
        self.leader_button = self.getImage(resource_path("assets/BtnLeader.png"))
        self.menu_button = self.getImage(resource_path("assets/BtnMenu.png"))
        self.select_button = self.getImage(resource_path("assets/BtnSelect.png"))

        self.crate_icon = self.getImage(resource_path("assets/Crate.png"))
        self.explosive_crate_icon = self.getImage(resource_path("assets/ExplosiveBarrel.png"))
        self.stream_icon = self.getImage(resource_path("assets/iconStream.png"))
        self.split_icon = self.getImage(resource_path("assets/iconSplit.png"))
        self.poop_icon = self.getImage(resource_path("assets/iconBurst.png"))
        self.q_icon = self.getImage(resource_path("assets/BalloonSmall2.png"))
        
        self.normal_icon = self.getImage(resource_path("assets/Balloon2.png"))

        self.shot_ammo_tile = AmmoTile(self.screen, self.normal_icon, self.hud_font)
        self.crate_ammo_tile = AmmoTile(self.screen, self.crate_icon, self.hud_font)
        self.explosivebarrel_ammo_tile = AmmoTile(self.screen, self.explosive_crate_icon, self.hud_font)
        
    def update(self):
        if self.state == 'ingame':

            tile_x = 0
            self.score_text = self.hud_font.render("Score: " + str(self.player.score), True, (255, 255, 255))
            self.lvlpop = self.lvl_font.render("You have reached Level " + str(self.level_number), True, (255, 255, 255))
        
            self.screen.blit(self.score_text, (10, 10))

            if self.player.shot_type == 'normal':
                self.shot_ammo_tile.icon = self.normal_icon
            elif self.player.shot_type == 'splitshot':
                self.shot_ammo_tile.icon = self.split_icon
            elif self.player.shot_type == 'streamshot':
                self.shot_ammo_tile.icon = self.stream_icon
            elif self.player.shot_type == 'poopshot':
                self.shot_ammo_tile.icon = self.poop_icon
            elif self.player.shot_type == 'qqq':
                self.shot_ammo_tile.icon = self.q_icon

            self.crate_ammo_tile.update(tile_x, self.screen.get_height(), self.player.crate_ammo)
            tile_x += self.crate_ammo_tile.width
            self.explosivebarrel_ammo_tile.update(tile_x, self.screen.get_height(), self.player.boom_ammo)
            tile_x += self.explosivebarrel_ammo_tile.width
            self.shot_ammo_tile.update(tile_x, self.screen.get_height(), self.player.special_ammo)

        elif self.state == 'mainmenu':
            print(" ")
            self.blink_timer -= 1
            if self.blink_timer <= 0:
                self.blink_timer = self.blink_timer_max
            title_x, title_y = toolbox.centeringXYZs(self.title_image, self.screen)
            self.screen.blit(self.title_image, (title_x, title_y))
            text_x, text_y = toolbox.centeringXYZs(self.start_text, self.screen)
            if self.blink_timer > 40:
                self.screen.blit(self.start_text, (text_x + 400, text_y - 200))
            text_x, text_y = toolbox.centeringXYZs(self.tutor_text, self.screen)
            text_y = self.screen.get_height() - 30
            self.screen.blit(self.tutor_text, (0, 15))
            self.screen.blit(self.credits, (0, 0))
            button_X, button_Y = toolbox.centeringXYZs(self.reset_button, self.screen)
            button_Y += 300
            button_r = self.screen.blit(self.select_button, (button_X, button_Y + 25))
            events = pygame.event.get()
            for event in events:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = pygame.mouse.get_pos()
                    if button_r.collidepoint(mouse_pos):
                        self.state = 'selection'
        

        elif self.state == 'gameover':
            
            
            text_X, text_Y = toolbox.centeringXYZs(self.gameover_text, self.screen)
            text_Y -= 40
            self.screen.blit(self.gameover_text, (text_X, text_Y))
            
            self.score_text = self.controls_font.render("Final Score: " + str(self.player.score), True, (255, 255, 255))

            if self.player.score >= self.highscore:
                print("e")
                self.highscore = self.player.score
 #               database.addScore(self.input_box.text, self.highscore)
                self.hstxt = "New Highscore!"
                self.highscorefile = open(resource_path("src/highscorefile.txt"), "w")
                self.highscorefile.write(str(self.highscore))
                self.highscorefile.close()
                
                self.input_box.update()
                self.screen.blit(self.texttext, (470, 180))
                self.input_box.draw(self.screen)
                
                #with open(self.highscorefile, "a") as f:
                    #f.write("new line\n")
            self.highscoretext = self.hUd_font.render(self.hstxt, True, (255, 255, 255))
            text_x, text_y = toolbox.centeringXYZs(self.score_text, self.screen)
            text_y += 40
            self.screen.blit(self.score_text, (text_x, text_y))
            self.screen.blit(self.highscoretext, (600, 50))
            
            button_x, button_y = toolbox.centeringXYZs(self.reset_button, self.screen)
            button_y += 120
            button_rect = self.screen.blit(self.reset_button, (button_x, button_y))
            button_X, button_Y = toolbox.centeringXYZs(self.reset_button, self.screen)
            button_Y += 240
            button_rekt = self.screen.blit(self.leader_button, (button_X, button_Y))

            events = pygame.event.get()
            for event in events:
                self.input_box.handle_event(event)
                if event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = pygame.mouse.get_pos()
                    if button_rect.collidepoint(mouse_pos):
                        self.state = 'mainmenu'                       
                    elif button_rekt.collidepoint(mouse_pos):
                        self.state = 'highscoremenu'
        elif self.state == 'highscoremenu':
            self.screen.blit(self.hsBG, (0, 0))
            button_X, button_Y = toolbox.centeringXYZs(self.reset_button, self.screen)
            button_Y += 325
            button_ret = self.screen.blit(self.reset_button, (button_X, button_Y))
            scores = database.topScore()
            high_X = 200
            high_Y = 100
            place = 1
            # TEXT BOX: https://www.codegrepper.com/code-examples/python/how+to+make+a+text+input+box+python+pygame
            if self.oo == False and len(self.input_box.text) > 0:
                database.addScore(self.input_box.text, self.highscore)
                self.oo = True
            for ID in scores:
                entry = scores[ID]
                user_text = self.hUd_font.render(str(place)+". "+entry["user"], True, ( 0, 0, 0))
                score_text = self.hUd_font.render(str(entry["score"]), True, (0, 0, 0))
                self.screen.blit(user_text, (high_X, high_Y))
                self.screen.blit(score_text, (high_X + 600, high_Y))
                high_Y += 15
                place += 1
                events = pygame.event.get()
                for event in events:
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        mouse_pos = pygame.mouse.get_pos()
                        if button_ret.collidepoint(mouse_pos):
                            self.state = 'mainmenu'
                            self.oo = True
        elif self.state == 'selection':
            print(" ")
            button_X, button_Y = toolbox.centeringXYZs(self.reset_button, self.screen)
            button_Y += 240
            self.screen.blit(self.select_image, (0, 0))
            button_re = self.screen.blit(self.menu_button, (button_X, button_Y + 85))
            button_1 = self.screen.blit(self.dad, (50, 100))
            button_2 = self.screen.blit(self.garfield, (700, 100))
            
            events = pygame.event.get()
            for event in events:
                if event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_pos = pygame.mouse.get_pos()
                    if button_re.collidepoint(mouse_pos):
                        self.state = 'mainmenu'
                    if button_1.collidepoint(mouse_pos):
                        self.player.image = self.getImage(resource_path("char/DadO.png"))
                        self.player.image_frame = self.getImage(resource_path("char/DadT.png"))
                    if button_2.collidepoint(mouse_pos):
                        self.player.image = self.getImage(resource_path("char/MomO.png"))
                        self.player.image_frame = self.getImage(resource_path("char/MomT.png"))
            if self.player.image == self.getImage(resource_path("char/MomO.png")):
                self.screen.blit(self.E, (780, 82.5))
            if self.player.image == self.getImage(resource_path("char/DadO.png")):
                self.screen.blit(self.E, (105, 82.5))
        
 
    
    def lvlUp(self):
        lvl_X, lvl_Y = toolbox.centeringXYZs(self.lvlpop, self.screen)
        self.screen.blit(self.lvlpop, (lvl_X, lvl_Y))
        self.lvltimer -= 1
            
            
class AmmoTile():
    def __init__(self, screen, icon, font):
        self.screen = screen
        self.icon = icon
        self.font = font
        self.bg_image = pygame.image.load(resource_path("assets/hudTile.png"))
        self.width = self.bg_image.get_width() + 3
    

    def update(self, x, y, ammo):
        tile_rect = self.bg_image.get_rect()
        tile_rect.bottomleft = (x, y)
        self.screen.blit(self.bg_image, tile_rect)

        icon_rect = self.icon.get_rect()
        icon_rect.center = tile_rect.center
        self.screen.blit(self.icon, icon_rect)

        ammo_text = self.font.render(str(ammo), True, (255, 255, 255))#"Cheat Code: spacetuberoads.com"
        self.screen.blit(ammo_text, tile_rect.topleft)
        
