import pygame
from src.explosion import Explosion
import sys
import os

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)


class Crate(pygame.sprite.Sprite):
    
    def __init__(self, screen, x, y, player):
        pygame.sprite.Sprite.__init__(self, self.containers)

        self.screen = screen
        self.x = x
        self.y = y
        self.player = player
        self.image = pygame.image.load(resource_path("assets/Crate.png"))
        self.image_hurt = pygame.image.load(resource_path("assets/Crate HURT.png"))
        self.explosion_mages = []
        self.explosion_mages.append(pygame.image.load(resource_path("assets/CrateRubble.png")))
        self.rect = self.image.get_rect()
        self.rect.center = (self.x, self.y)
        self.health = 45
        self.health_timer = 0
        self.just_placed = True
        self.sfx_break = pygame.mixer.Sound(resource_path("assets/sfx/break.wav"))

    def update(self, projectiles, explosions):
        if not self.rect.colliderect(self.player.rect):
            self.just_placed = False


        for explosion in explosions:
            if explosion.damage:
                if self.rect.colliderect(explosion.rect):
                    self.getHit(explosion.damage)
                    
        for projectile in projectiles:
            if self.rect.colliderect(projectile.rect):
                projectile.explode()
                self.getHit(projectile.damage)

        if self.health_timer > 0:
            self.health_timer -= 1
            image_to_draw = self.image_hurt
        else:
            image_to_draw = self.image
        
        self.screen.blit(image_to_draw, self.rect)

    def getHit(self, damage):
        self.health -= damage
        self.health_timer = 9
        if self.health <= 0:
            self.health = 10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
            Explosion(self.screen, self.x, self.y, self.explosion_mages, 10, 0, False)
            self.sfx_break.play()
            self.kill()

class ExplosiveCrate(Crate):
        
    def __init__(self, screen, x, y, player):
        
        Crate.__init__(self, screen, x, y, player)
    
        self.image = pygame.image.load(resource_path("assets/ExplosiveBarrel.png"))
        self.image_hurt = pygame.image.load(resource_path("assets/ExplosiveBarrel HURT.png"))
        self.health = 20
        self.explosion_mages =[]
        self.explosion_mages.append(pygame.image.load(resource_path("assets/LargeExplosion1.png")))
        self.explosion_mages.append(pygame.image.load(resource_path("assets/LargeExplosion2.png")))
        self.explosion_mages.append(pygame.image.load(resource_path("assets/LargeExplosion3.png")))
        self.sfx_boom = pygame.mixer.Sound(resource_path("assets/sfx/explosion-big.wav"))

    def getHit(self, damage):
        self.health -= damage
        self.health_timer = 9
        if self.health <= 0:
            self.health = 10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
            Explosion(self.screen, self.x, self.y, self.explosion_mages, 5, 0.6, True)
            self.sfx_boom.play()
            self.kill()
        

         
