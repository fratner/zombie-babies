import firebase_admin
from firebase_admin import credentials
from firebase_admin import db
import json
from collections import OrderedDict

import os
import sys
def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

def startUp():
 #   cred = credentials.Certificate("attack-of-the-zombie-babies-firebase-adminsdk-fczba-239a1f7081.json")
 #   app = firebase_admin.initialize_app(cred, {"databaseURL":"https://attack-of-the-zombie-babies.firebaseio.com/"})
     cred = credentials.Certificate(resource_path("src/attack-of-the-zombie-bab-b8c3a-firebase-adminsdk-fa288-8229687a42.json"))
     app = firebase_admin.initialize_app(cred, {"databaseURL":"https://attack-of-the-zombie-bab-b8c3a.firebaseio.com/"})

def getScore():
    ref = db.reference("highscores")
    return ref.get()
def addScore(user, score):
    ref = db.reference("highscores")
    ref.push().update({"user":user, "score":score})
def topScore():
    ref = db.reference("highscores")
    snapshot = ref.order_by_child("score").limit_to_last(50).get()
    highscorelist = OrderedDict(reversed(list(snapshot.items())))
    return highscorelist
