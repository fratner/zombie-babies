import pygame
import src.toolbox as toolbox
import math
from src.explosion import Explosion
import random
from src.powerup import PowerUp
import sys
import os

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)


class Enemy(pygame.sprite.Sprite):
    def __init__(self, screen, x, y, player, image, image_hurt, frame, pamage, pealth, peed, pore, ree):
        pygame.sprite.Sprite.__init__(self, self.containers)

        self.screen = screen
        self.x = x
        self.y = y
        self.player = player
        self.image = image
        self.image_hurt = image_hurt
        self.image_frame = frame
        self.explosion_images = []
        self.explosion_images.append(pygame.image.load(resource_path("assets/MediumExplosion1.png")))
        self.explosion_images.append(pygame.image.load(resource_path("assets/MediumExplosion2.png")))
        self.explosion_images.append(pygame.image.load(resource_path("assets/MediumExplosion3.png")))
        self.rect = self.image.get_rect()
        self.rect.center = (self.x, self.y)
        self.angle = 0
        self.speed = peed#2.9
        self.health = pealth#24
        self.hurt_timer = 0
        self.damage = pamage#1.6
        self.anger = 0
        self.max_mad = 100
        self.powerup_drop_chance = 15
        self.sfx_die = pygame.mixer.Sound(resource_path("assets/sfx/explosion-small.wav"))
        self.animation_timer_max = 45
        self.animation_timer = self.animation_timer_max
        self.aniframe = 0
        self.pore = pore
        self.ree = 10
        self.boss_dead = False

    def update(self, projectiles, crates, explosions):

        self.angle = toolbox.angleBetweenPoints(self.x, self.y, self.player.x, self.player.y)

        self.animation_timer -= 1

        angle_rads = math.radians(self.angle)
        self.x_move = math.cos(angle_rads) * self.speed
        self.y_move = -math.sin(angle_rads) * self.speed

        test_rect = self.rect
        new_x = self.x + self.x_move
        new_y = self.y + self.y_move

        test_rect.center = (new_x, self.y)

        for crate  in crates:
            if test_rect.colliderect(crate.rect):
                new_x = self.x
                self.getAngry(crate)

        test_rect.center = (self.x, new_y)
        for crate in crates:
            if test_rect.colliderect(crate.rect):
                new_y = self.y
                self.getAngry(crate)
        
        self.x = new_x
        self.y = new_y 
        self.rect.center = (self.x, self.y)

        for projectile in projectiles:
            if self.rect.colliderect(projectile.rect):
                self.getHit(projectile.damage)
                projectile.explode()
        for explosion in explosions:
            if explosion.damage:
                if self.rect.colliderect(explosion.rect):
                    self.getHit(explosion.damage)
                    

        if self.hurt_timer <= 0:
            image_to_rotate = self.image 
        else:
            image_to_rotate = self.image_hurt
            self.hurt_timer -= 1
        if self.animation_timer <= 0:
            self.animation_timer = self.animation_timer_max
            self.aniframe += 1
            if self.aniframe > 1:
                self.aniframe = 0
        else:
            self.animation_timer -= 1

        if self.aniframe == 0:
            image_to_rotate = self.image_frame
        else:
            image_to_rotate = self.image

        
        image_to_draw, image_rect = toolbox.getRotatedImage(image_to_rotate, self.rect, self.angle)

        self.screen.blit(image_to_draw, image_rect)

        

    def getHit(self, damage):
        if damage:
            self.hurt_timer = 6
        self.x -= self.x_move * 2
        self.y -= self.y_move * 2
        self.health -= damage
        if self.health <= 0:
            self.sfx_die.play()
            self.health = 10000000000000
            self.player.getScore(self.pore)
            Explosion(self.screen, self.x, self.y, self.explosion_images, 6, 0, False)
            if random.randint(0, 100) < self.powerup_drop_chance:
                PowerUp(self.screen, self.x, self.y)
            self.ree = 80
            self.boss_dead = True
            self.kill()

    def getAngry(self, crate):
        self.anger += 1
        if self.anger >= self.max_mad:
            crate.getHit(self.damage)
            self.anger = 0
    def getP00PEDON(self):
        boss_dead = True
        return boss_dead
        












            
