import pygame
import src.toolbox as toolbox
import src.projectile as projectile
from src.crate import Crate
from src.crate import ExplosiveCrate
import sys
import os

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

class Player(pygame.sprite.Sprite):
    #CONSTRUCT THE PLAYER
    def __init__(self, screen, x, y):

        pygame.sprite.Sprite.__init__(self, self.containers)
        
        self.screen = screen
        self.y = y
        self.x = x
        self.image = pygame.image.load(resource_path("char/DadO.png"))
        self.image_frame = pygame.image.load(resource_path("char/DadT.png"))
        self.image_youch = pygame.image.load(resource_path("assets/tired mom.png"))
        self.image_defeat = pygame.image.load(resource_path("assets/Enemy_04.png"))
        self.rect = self.image.get_rect()
        self.rect.center = (self.x, self.y)
        self.speed = 5
        self.angle = 0
        self.shoot_cooldown = 0
        self.shoot_cooldown_max = 15
        self.health_max = 30
        self.health =  self.health_max
        self.health_bar_width = self.image.get_width()
        self.health_bar_height = 8
        self.health_bar_green = pygame.Rect(-100, -100, self.health_bar_width, self.health_bar_height)
        self.health_bar_red = pygame.Rect(-100, -100, self.health_bar_width, self.health_bar_height)
        self.alive = True
        self.hurt_timer = 0
        self.crate_ammo = 15
        self.boom_ammo = 10
        self.crate_cooldown = 0
        self.crate_cooldown_max = 20
        self.shot_type = 'normal'
        self.special_ammo = 0
        self.score = 0
        self.sfx_shoot = pygame.mixer.Sound(resource_path("assets/sfx/shot.wav"))
        self.sfx_die = pygame.mixer.Sound(resource_path("assets/sfx/electrocute.wav"))
        self.sfx_crate = pygame.mixer.Sound(resource_path("assets/sfx/bump.wav"))
        self.speed_timer = 0
        self.animation_timer_max = 45
        self.animation_timer = self.animation_timer_max
        self.aniframe = 0
        
        

#UPDATE
    def update(self, enemies, explosions):
        self.rect.center = (self.x, self.y)
        self.speed_timer -= 1
        self.animation_timer -= 1
        if self.speed_timer <= 0:
            self.speed = 5
        
        for explosion in explosions:
            if explosion.damage_player and explosion.damage:
                if self.rect.colliderect(explosion.rect):
                    self.getHit(explosion.damage)
                
        for enemy in enemies:
            if self.rect.colliderect(enemy.rect):
                enemy.getHit(0)
                self.getHit(enemy.damage)
        if self.alive:
            mouse_x, mouse_y = pygame.mouse.get_pos()

            self.angle = toolbox.angleBetweenPoints(self.x, self.y, mouse_x, mouse_y)

        if self.shoot_cooldown > 0:
            self.shoot_cooldown -= 1
        if self.crate_cooldown > 0:
            self.crate_cooldown -= 1

        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.right > self.screen.get_width():
            self.rect.right = self.screen.get_width()
        if self.rect.top < 0:
            self.rect.top = 0
        if self.rect.bottom > self.screen.get_height():
            self.rect.bottom = self.screen.get_height()
        self.x = self.rect.centerx
        self.y = self.rect.centery
        
#ROTATE
        if self.alive:
            if self.hurt_timer > 0:
                image_to_rotate = self.image_youch
                self.hurt_timer -= 1
            else:
                image_to_rotate = self.image
        else:
            image_to_rotate = self.image_defeat

        if self.animation_timer <= 0:
            self.animation_timer = self.animation_timer_max
            self.aniframe += 1
            if self.aniframe > 1:
                self.aniframe = 0
        else:
            self.animation_timer -= 1

        if self.aniframe == 0:
            image_to_rotate = self.image_frame
        else:
            image_to_rotate = self.image
        
        image_to_draw, image_rect = toolbox.getRotatedImage(image_to_rotate, self.rect, self.angle)


#DRAW
        
        self.screen.blit(image_to_draw, image_rect)
#HEALTHBAR
        #LOCATE
        self.health_bar_red.x = self.rect.x
        self.health_bar_red.bottom = self.rect.y - 5
        self.health_bar_green.topleft = self.health_bar_red.topleft
        health_percentage = self.health / self.health_max
        self.health_bar_green.width = self.health_bar_width * health_percentage
        pygame.draw.rect(self.screen, (255, 0, 0), self.health_bar_red)
        if self.alive:
            pygame.draw.rect(self.screen, (0, 255, 0), self.health_bar_green)
#WALK
    def move(self, x_movement, y_movement, crates):
        if self.alive:
            test_rect = self.rect
            test_rect.x += self.speed * x_movement
            test_rect.y += self.speed * y_movement
            collision = False
            for crate in crates:
                if not crate.just_placed:
                    if test_rect.colliderect(crate.rect):
                        collision = True                       
            if not collision:  
                self.x += self.speed * x_movement
                self.y += self.speed * y_movement
#SHOOT
    def shoot(self):
        if self.shoot_cooldown <= 0 and self.alive:
            self.sfx_shoot.play()
            if self.shot_type == 'normal':#milkbottle
                projectile.tsarBomb(self.screen, self.x, self.y, self.angle)
            elif self.shot_type == 'splitshot':#split
                 projectile.splitShot(self.screen, self.x, self.y, self.angle-15)
                 projectile.splitShot(self.screen, self.x, self.y, self.angle+15)
                 projectile.splitShot(self.screen, self.x, self.y, self.angle)
                 self.special_ammo -= 1 
            elif self.shot_type == 'streamshot':#stream
                projectile.streamShot(self.screen, self.x, self.y, self.angle)
                self.special_ammo -= 1               
            elif self.shot_type == 'poopshot':#diaper
                projectile.boomShot(self.screen, self.x, self.y, self.angle)
                self.special_ammo -= 1
            elif self.shot_type == 'qqq':
                projectile.q(self.screen, self.x, self.y, self.angle)
                self.special_ammo -= 1 
            self.shoot_cooldown = self.shoot_cooldown_max
            if self.special_ammo <= 0:
                self.powerUp('normal')
 #GET DED
    def getHit(self, damage):
        if self.alive:
            self.hurt_timer = 6
            self.health -= damage
            if self.health <= 0:
                self.sfx_die.play()
                self.health = 0
                self.alive = False
                
# CRATE
    def placeCrate(self):
        if self.alive and self.crate_ammo > 0 and self.crate_cooldown <= 0:
            self.sfx_crate.play()
            Crate(self.screen, self.x, self.y, self)
            self.crate_ammo -= 1
            self.crate_cooldown = self.crate_cooldown_max
    def placeBoomCrate(self):
        if self.alive and self.boom_ammo > 0 and self.crate_cooldown <= 0:
            self.sfx_crate.play()
            ExplosiveCrate(self.screen, self.x, self.y, self)
            self.boom_ammo -= 1
            self.crate_cooldown = self.crate_cooldown_max
#POWERUP
    def powerUp(self, power_type):
        if power_type == 'normal':
            self.shot_type = 'normal'
            self.shoot_cooldown_max = 15
        elif power_type == 'crateammo':
            self.crate_ammo += 10
            self.getScore(5)
        elif power_type == 'explosivebarrelammo':
            self.boom_ammo += 10
            self.getScore(10)
        elif power_type == 'splitshot':
            self.shot_type = 'splitshot'
            self.special_ammo = 10
            self.shoot_cooldown_max = 10
            self.getScore(20)
        elif power_type == 'streamshot':
            self.shot_type = 'streamshot'
            self.special_ammo = 200
            self.shoot_cooldown_max = 0.1
            self.getScore(20)
        elif power_type == 'poopshot':
            self.shot_type = 'poopshot'
            self.special_ammo = 10
            self.shoot_cooldown_max = 25
            self.getScore(45)
        elif power_type == 'q':
            self.shot_type = 'qqq'
            self.special_ammo = 5
            self.shoot_cooldown_max = 20
            self.getScore(50)
        elif power_type == 'hpp':
            self.getScore(10)
            self.health += 10
        elif power_type == 'spud':
            self.getScore(20)
            self.speed_timer = 1000
            self.speed = 10
#SCOREBOARD
    def getScore(self, score):
        if self.alive:
            self.score += score

        
    
                
        




















    
