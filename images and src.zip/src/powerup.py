import pygame
import src.toolbox as toolbox
import random
import os
import sys
def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)
class PowerUp(pygame.sprite.Sprite):
    def __init__(self, screen, x, y):
        pygame.sprite.Sprite.__init__(self, self.containers)
        self.screen = screen
        self.x = x
        self.y = y
        self.pick_power = random.randint(0, 7)
        self.sfx_get = pygame.mixer.Sound(resource_path("assets/sfx/powerup.wav"))
        
        if self.pick_power == 0:#crateammo
            self.image = pygame.image.load(resource_path("assets/powerupCrate.png"))
            self.back_image = pygame.image.load(resource_path("assets/powerupBackgroundBlue.png"))
            self.power_type = 'crateammo'
            
        elif self.pick_power == 1:#explosivebarrelammo
            self.image = pygame.image.load(resource_path("assets/powerupExplosiveBarrel.png"))
            self.back_image = pygame.image.load(resource_path("assets/powerupBackgroundBlue.png"))
            self.power_type = 'explosivebarrelammo'
            
        elif self.pick_power == 2:#splitshot
            self.image = pygame.image.load(resource_path("assets/powerupSplit.png"))
            self.back_image = pygame.image.load(resource_path("assets/powerupBackgroundBlue.png"))
            self.power_type = 'splitshot'
            
        elif self.pick_power == 3:#streamshot
            self.image = pygame.image.load(resource_path("assets/powerupDrop.png"))
            self.back_image = pygame.image.load(resource_path("assets/powerupBackgroundBlue.png"))
            self.power_type = 'streamshot'

        elif self.pick_power == 4:#poopshot
            self.image = pygame.image.load(resource_path("assets/BalloonSmall.png"))
            self.back_image = pygame.image.load(resource_path("assets/powerupBackgroundBlue.png"))
            self.power_type = 'poopshot'

        elif self.pick_power == 5:#q
            self.image = pygame.image.load(resource_path("assets/BalloonSmall2.png"))
            self.back_image = pygame.image.load(resource_path("assets/powerupBackgroundBlue.png"))
            self.power_type ='q'

        elif self.pick_power == 6:#hpp
            self.image = pygame.image.load(resource_path("assets/Health.png"))
            self.back_image = pygame.image.load(resource_path("assets/powerupBackgroundBlue.png"))
            self.power_type ='hpp'

        elif self.pick_power == 7:#spud
            self.image = pygame.image.load(resource_path("assets/SPUD.png"))
            self.back_image = pygame.image.load(resource_path("assets/powerupBackgroundBlue.png"))
            self.power_type ='spud'
            
        self.rect = self.image.get_rect()
        self.rect.center = (self.x, self.y)
        self.back_angle = 0
        self.spinny_speed = 2
        self.despawn_timer = 400
        
        
            
    def update(self, player):
        
        if self.rect.colliderect(player.rect):
            player.powerUp(self.power_type)
            self.sfx_get.play()
            self.kill()
        self.despawn_timer -= 1
        if self.despawn_timer <= 0:
            self.kill()
        self.back_angle += self.spinny_speed
        bg_image_to_draw, bg_rect = toolbox.getRotatedImage(self.image, self.rect, self.back_angle)

        if self.despawn_timer > 120 or self.despawn_timer % 10 > 3.5:
           
            self.screen.blit(bg_image_to_draw, bg_rect)
        
 
