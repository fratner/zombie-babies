import pygame
import src.toolbox as toolbox
import math
import random
from src.explosion import Explosion
import os
import sys
def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)
class tsarBomb(pygame.sprite.Sprite):
    def __init__(self, screen, x, y, angle):
        pygame.sprite.Sprite.__init__(self, self.containers)

        self.x = x
        self.y = y
        self.screen = screen
        self.angle = angle
        self.image = pygame.image.load(resource_path("assets/Balloon2.png"))
        self.list01 = []
        self.list01.append(pygame.image.load(resource_path("assets/SmallExplosion1.png")))
        self.list01.append(pygame.image.load(resource_path("assets/SmallExplosion2.png")))
        self.list01.append(pygame.image.load(resource_path("assets/SmallExplosion3.png")))

        
        self.rect = self.image.get_rect()
        self.rect.center = (self.x, self.y)
        self.image, self.rect = toolbox.getRotatedImage(self.image, self.rect, self.angle)
        self.speed = 10
        self.angle_rads = math.radians(self.angle)
        self.x_move = math.cos(self.angle_rads) * self.speed
        self.y_move = -math.sin(self.angle_rads) * self.speed
        self.damage = 6
        self.sfx_splash = pygame.mixer.Sound(resource_path("assets/sfx/splash.wav"))
        self.sfx_sploosh = pygame.mixer.Sound(resource_path("assets/sfx/splash-heavy.wav"))

    def update(self):
        self.x += self.x_move
        self.y += self.y_move
        self.rect.center = (self.x, self.y)

# DESPAWN
        if self.x < -self.image.get_width():
            self.kill()
        elif self.x > self.screen.get_width() + self.image.get_width():
            self.kill()
        elif self.y < -self.image.get_height():
            self.kill()
        elif self.y > self.screen.get_height() + self.image.get_height():
            self.kill()
 
        
        self.screen.blit(self.image, self.rect)

    def explode(self):
        Explosion(self.screen, self.x, self.y, self.list01, 5, 0, False)
        self.sfx_splash.play()
        self.kill()


class splitShot(tsarBomb):
    def __init__(self, screen, x, y, angle):
        tsarBomb.__init__(self, screen, x, y, angle)
        self.damage = 12
        #self.image = pygame.image.load("../assets/Balloon2 copy.png")
        #self.rect = self.image.get_rect()
        #self.image, self.rect = toolbox.getRotatedImage(self.image, self.rect, self.angle)


class streamShot(tsarBomb):
    def __init__(self, screen, x, y, angle):
        tsarBomb.__init__(self, screen, x, y, angle)
        self.image = pygame.image.load(resource_path("assets/Drop.png"))
        self.rect = self.image.get_rect()
        self.image, self.rect = toolbox.getRotatedImage(self.image, self.rect, self.angle)
        self.damage = 4

class boomShot(tsarBomb):
    def __init__(self, screen, x, y, angle):
        tsarBomb.__init__(self, screen, x, y, angle)
        self.image = pygame.image.load(resource_path("assets/Balloon.png"))
        self.rect = self.image.get_rect()
        self.image, self.rect = toolbox.getRotatedImage(self.image, self.rect, self.angle)
        self.damage = 24

        self.list01 = []
        self.list01.append(pygame.image.load(resource_path("assets/SplashLarge1.png")))
        self.list01.append(pygame.image.load(resource_path("assets/SplashLarge2.png")))
        self.list01.append(pygame.image.load(resource_path("assets/SplashLarge3.png")))

    def explode(self):
        Explosion(self.screen, self.x, self.y, self.list01, 5, 2, False)
        self.sfx_sploosh.play()
        self.kill()

class q(tsarBomb):
    def __init__(self, screen, x, y, angle):
        tsarBomb.__init__(self, screen, x, y, angle)
        self.image = pygame.image.load(resource_path("assets/BalloonSmall2.png"))
        self.rect = self.image.get_rect()
        self.image, self.rect = toolbox.getRotatedImage(self.image, self.rect, self.angle)
        self.damage = 23
        self.speed = 3
        self.x_move = math.cos(self.angle_rads) * self.speed
        self.y_move = -math.sin(self.angle_rads) * self.speed

    def explode(self):
        q(self.screen, self.x, self.y, random.randint(0, 360))
        Explosion(self.screen, self.x, self.y, self.list01, 5, 0, False)
        self.sfx_sploosh.play()
        self.kill()
  

        



























    
        
        
