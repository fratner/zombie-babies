import pygame 
from src.player import Player
from src.projectile import tsarBomb
from src.enemy import Enemy
import random
from src.crate import Crate
from src.explosion import Explosion
from src.crate import ExplosiveCrate
from src.powerup import PowerUp
from src.HUD import HUD
import src.database as database

import os
import sys
def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)


# START
pygame.init()
pygame.mixer.pre_init(buffer=1024)
game_width = 1280
game_height = 720
screen = pygame.display.set_mode((game_width, game_height))
clock = pygame.time.Clock()
running = True

images = {}

def getImage(file):
    if file in images:
        return images.get(file)
    else:
        images[file] = pygame.image.load(file)
        return images.get(file)
database.startUp()

background_image = getImage(resource_path("backgrounds/nursery.png"))
background_image2 = getImage(resource_path("backgrounds/livingroom.png"))
background_image3 = getImage(resource_path("backgrounds/amusementpark.png"))
background_image4 = getImage(resource_path("backgrounds/forest.png"))
background_image5 = getImage(resource_path("backgrounds/Boat.png"))



boss_time = 'false'
#CREATE GROUPS
playerGroup = pygame.sprite.Group()
projectilesGroup = pygame.sprite.Group()
enemyGroup = pygame.sprite.Group()
cratesGroup = pygame.sprite.Group()
explosionGroup = pygame.sprite.Group()
powerupGroup = pygame.sprite.Group()
#ADD TO GROUP
Player.containers = playerGroup
tsarBomb.containers = projectilesGroup
Enemy.containers = enemyGroup
Crate.containers = cratesGroup
Explosion.containers = explosionGroup
PowerUp.containers = powerupGroup

enemy_spawn_timer_max = 80
enemy_spawn_timer = 0

enemy_spawn_speed_max = 600
enemy_spawn_speed = enemy_spawn_speed_max

music1 = pygame.mixer.music.load(resource_path("music/sneakysnek.mp3"))
#music2 = pygame.mixer.music.load("../music/sneakysneak.mp3")
pygame.mixer.music.set_volume(0.5)
pygame.mixer.music.play(-1)


###
#Here is firebase startup:  export GOOGLE_APPLICATION_CREDENTIALS="Macintosh HD/Users/paulratner27/Dropbox/Zombie Babies/src/attack-of-the-zombie-babies-firebase-adminsdk-fczba-239a1f7081.json"
###
game_started = False

player_1 = Player(screen, game_width/2, game_height/2)

hud = HUD(screen, player_1)

boss_time = False

def StartGame():
    global game_started
    global hud
    global player
    global background_image
    global enemy_spawn_timer_max
    global enemy_spawn_timer
    global enemy_spawn_speed
    global boss_time

    enemy_spawn_timer_max = 80
    enemy_spawn_timer = 0
    enemy_spawn_speed = enemy_spawn_speed_max

    pygame.mixer.music.load(resource_path("music/sneakysnek.mp3"))
    background_image = getImage(resource_path("backgrounds/nursery.png"))
    
    game_started = True

    hud.state = 'ingame'
    hud.level_number = 1

    boss_time = False
    
    player_1.x = 500
    player_1.y = 325
    player_1.alive = True
    player_1.health = player_1.health_max
    player_1.crate_ammo = 15
    player_1.boom_ammo = 10
    player_1.special_ammo = 0
    player_1.score = 0

    for i in range(0, 5):
        ExplosiveCrate(screen, random.randint(0, game_width), random.randint(0, game_height), player_1)
        Crate(screen, random.randint(0, game_width), random.randint(0, game_height), player_1)

    screen.blit(background_image, (0, 0))



# ***************** LOOPS *****************
while running:
    #STOP
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.mixer.music.stop()
            running = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            pygame.mixer.music.stop()
            running = False

 
            
   

    if not game_started:
        print("")
        events = pygame.event.get()
        for event in events:
            if (event.type == pygame.KEYUP or event.type == pygame.KEYDOWN) and hud.state == "mainmenu":
                StartGame()
 
                pygame.mixer.music.play(-1)
                break
            
    if game_started:

        screen.blit(background_image, (0, 0))
        
        keys = pygame.key.get_pressed()
        if keys[pygame.K_w]:
            player_1.move(0, -1, cratesGroup)
        if keys[pygame.K_a]:
            player_1.move(-1, 0, cratesGroup)
        if keys[pygame.K_s]:
            player_1.move(0, 1, cratesGroup)
        if keys[pygame.K_d]:
            player_1.move(1, 0, cratesGroup)
        


         #SHOOT
        if pygame.mouse.get_pressed()[0]:
            player_1.shoot()
        if keys[pygame.K_e]:
            player_1.placeCrate()
        if pygame.mouse.get_pressed()[2]:
            player_1.placeBoomCrate()
    
        #SPAWN DA ENEMY
 #       boss_poo = Enemy.getP00PEDON(8)
     #   if boss_poo:
 #           enemy_spawn_timer = 80



            
        enemy_spawn_speed -= 1
        if enemy_spawn_speed <= 0:
            if enemy_spawn_timer_max > 1:
                enemy_spawn_timer_max -= 5
            enemy_spawn_speed = enemy_spawn_speed_max
            
        enemy_spawn_timer -= 1
        if enemy_spawn_timer <= 0:
            if not boss_time:# and Boss.boss_time == False:
                picenemy = random.randint(0, 3)
                pice = getImage(resource_path("assets/air.png"))
                pice2 = pice
                pice3 = getImage(resource_path("assets/air.png"))
                pamage = 0
                pealth = 0
                peed = 0
                pore = 1
                ree = 1
                boss_time = False
                boss_type = 'null'
                if picenemy == 0:
                    pice = getImage(resource_path("new/zombiebaby64.png"))
                    pice2 = pice
                    pice3 = getImage(resource_path("new/zombiebaby64_2.png"))
                    peed = 2.9
                    pealth = 24
                    pamage = 1.6
                    pore = 50
                    ree = 80
                if picenemy == 1:
                    pice = getImage(resource_path("new/rainbowbaby64.png"))
                    pice2 = pice
                    pice3 = getImage(resource_path("new/rainbowbaby64_2.png"))
                    peed = 2.9
                    pealth = 30
                    pamage = 1
                    pore = 10
                    ree = 80
                if picenemy == 2:
                    pice = getImage(resource_path("new/piratebaby64.png"))
                    pice2 = pice
                    pice3 = getImage(resource_path("new/piratebaby64_2.png"))
                    peed = 2.6
                    pealth = 24
                    pamage = 2
                    pore = 10
                    ree = 80
                if picenemy == 3:
                    pice = getImage(resource_path("new/hunter64.png"))
                    pice2 = pice
                    pice3 = getImage(resource_path("new/hunter64_2.png"))
                    peed = 3
                    pealth = 24
                    pamage = 3
                    pore = 10
                    ree = 80
                
            if player_1.score > 100 and player_1.score < 200:
                boss_time = True
                boss_type = 'b1'
            if player_1.score > 400 and player_1.score < 500:
                boss_time = True
                boss_type = 'b2'
            if player_1.score > 600 and player_1.score < 700:
                boss_time = True
                boss_type = 'b3'
            if player_1.score > 800 and player_1.score < 900:
                boss_time = True
                boss_type = 'b4'
            if player_1.score > 1000 and player_1.score < 1100:
                boss_time = True
                boss_type = 'b5'
                
           # elif player_1.score > 300:
 #              pice = pygame.image.load("../assets/.png")
 #               pice2 = pygame.image.load("../assets/.png")
 #               pice3 = pygame.image.load("../assets/.png")
 #               pamage = 30
 #               pealth = 500
 #               peed = 3
 #               pore = 300
 #           elif player_1.score > 300:
 #               pice = pygame.image.load("../assets/.png")
 #               pice2 = pygame.image.load("../assets/.png")
 #               pice3 = pygame.image.load("../assets/.png")
 #               pamage = 30
 #               pealth = 500
 #               peed = 3
 #               pore = 300
 #           elif player_1.score > 300:
 #               pice = pygame.image.load("../assets/.png")
 #               pice2 = pygame.image.load("../assets/.png")
 #               pice3 = pygame.image.load("../assets/.png")
 #               pamage = 30
 #               pealth = 500
 #               peed = 3
 #               pore = 300


  #          if Boss.boss_time == Tr
            if boss_type == 'b1' and boss_time:
                pice = getImage(resource_path("new/zombiecat128.png"))
                pice2 = pice
                pice3 = getImage(resource_path("new/zombiecat128_2.png"))
                pamage = 10
                pealth = 300
                peed = 3.5
                pore = 100
                enemy_spawn_timer_max = 100000000000000000000000000000000000000000000000000000
            if boss_type == 'b2' and boss_time:
                pice = getImage(resource_path("new/pianobaby128.png"))
                pice2 = pice
                pice3 = getImage(resource_path("new/pianobaby128_2"))
                pamage = 10
                pealth = 500
                peed = 5
                pore = 100
                enemy_spawn_timer_max = 100000000000000000000000000000000000000000000000000000
            if boss_type == 'b3' and boss_time:
                pice = getImage(resource_path("new/clown1.png"))
                pice2 = pice
                pice3 = getImage(resource_path("new/clown2.png"))
                pamage = 10
                pealth = 700
                peed = 7
                pore = 100
                enemy_spawn_timer_max = 100000000000000000000000000000000000000000000000000000
            if boss_type == 'b4' and boss_time:
                pice = getImage(resource_path("new/axe128.png"))
                pice2 = pice
                pice3 = getImage(resource_path("new/axe128_2.png"))
                pamage = 10
                pealth = 700
                peed = 4
                pore = 100
                enemy_spawn_timer_max = 100000000000000000000000000000000000000000000000000000
            if boss_type == 'b5' and boss_time:
                pice = getImage(resource_path("new/whale1.png"))
                pice2 = pice
                pice3 = getImage(resource_path("new/whale2.png"))
                pamage = 10
                pealth = 1000
                peed = 8
                pore = 100
                enemy_spawn_timer_max = 100000000000000000000000000000000000000000000000000000
  
 
            new_enemy = Enemy(screen, 0, 0, player_1, pice, pice2, pice3, pamage, pealth, peed, pore, ree)
            if not boss_time:
                enemy_spawn_timer_max = 80
            side_to_spawn = random.randint(0, 3)
            if side_to_spawn == 0:
                new_enemy.x = random.randint(0, game_width)
                new_enemy.y = -new_enemy.image.get_height()
            elif side_to_spawn == 1:
                new_enemy.x = random.randint(0, game_width)
                new_enemy.y = game_height + new_enemy.image.get_height()
            elif side_to_spawn == 2:
                new_enemy.x = -new_enemy.image.get_width()
                new_enemy.y = random.randint(0, game_height)
            elif side_to_spawn == 3:
                new_enemy.x = game_width + new_enemy.image.get_width()
                new_enemy.y = random.randint(0, game_height)
            if not boss_time:
                enemy_spawn_timer = enemy_spawn_timer_max
            if boss_time:
                enemy_spawn_timer = enemy_spawn_timer_max
                enemy_spawn_timer_max = 80
                boss_time = False
                boss_type = 'null'
                
 
    #CREATE THINGS
        

        for projectile in projectilesGroup:
            projectile.update()
        for enemy in enemyGroup:
            enemy.update(projectilesGroup, cratesGroup, explosionGroup)
        for crate in cratesGroup:
            crate.update(projectilesGroup, explosionGroup)
        for explosion in explosionGroup:
            explosion.update()
        for powerup in powerupGroup:
            powerup.update(player_1)
        
        player_1.update(enemyGroup, explosionGroup)

        if not player_1.alive:
            if hud.state == 'ingame':
                hud.state = 'gameover'
            if hud.state == 'mainmenu':
                game_started = False
                playerGroup.empty()
                projectilesGroup.empty()
                enemyGroup.empty()
                cratesGroup.empty()
                explosionGroup.empty()
                powerupGroup.empty()
            if hud.state == 'highscoremenu':
                game_started = False
                playerGroup.empty()
                projectilesGroup.empty()
                enemyGroup.empty()
                cratesGroup.empty()
                explosionGroup.empty()
                powerupGroup.empty()
            if hud.state == 'selection':
                game_started = False
                playerGroup.empty()
                projectilesGroup.empty()
                enemyGroup.empty()
                cratesGroup.empty()
                explosionGroup.empty()
                powerupGroup.empty()
 #   screen.blit(background_image, (0, 0))
    if player_1.score > 100 and player_1.score < 200:
 #       pygame.mixer.music.stop()
 #       pygame.mixer.music.play(-1)
        background_image = background_image
        if hud.level_number < 2:
            
            hud.level_number += 1
            pygame.mixer.music.load(resource_path("music/sneakysneak.mp3"))#sample rate == 44,100
            pygame.mixer.music.stop()
            pygame.mixer.music.play(-1)
        hud.lvlUp()
        
    if player_1.score > 200 and player_1.score < 400:
        
        background_image = background_image2
        if hud.level_number < 3:#3
            hud.level_number += 1
            pygame.mixer.music.load(resource_path("music/living room.mp3"))
            pygame.mixer.music.stop()
            pygame.mixer.music.play(-1)
        hud.lvlUp()
    if player_1.score > 400 and player_1.score < 500:
        background_image = background_image2#4
        if hud.level_number < 4:
            hud.level_number += 1
            pygame.mixer.music.load(resource_path("music/piano.mp3"))
            pygame.mixer.music.stop()
            pygame.mixer.music.play(-1)
           
        hud.lvlUp()
    if player_1.score > 500 and player_1.score < 600:#5
        background_image = background_image3
        if hud.level_number < 5:
            hud.level_number += 1
            pygame.mixer.music.load(resource_path("music/amusement.mp3"))
            pygame.mixer.music.stop()
            pygame.mixer.music.play(-1)
        hud.lvlUp()
    if player_1.score > 600 and player_1.score < 700:#6
       background_image = background_image3
       if hud.level_number < 6:
           hud.level_number += 1
           pygame.mixer.music.load(resource_path("music/clown.mp3"))
           pygame.mixer.music.stop()
           pygame.mixer.music.play(-1)
       hud.lvlUp()
    if player_1.score > 700 and player_1.score < 800:#7
       background_image = background_image4
       if hud.level_number < 7:
           hud.level_number += 1
           pygame.mixer.music.load(resource_path("music/forest2.mp3"))
           pygame.mixer.music.stop()
           pygame.mixer.music.play(-1)
       hud.lvlUp()
    if player_1.score > 800 and player_1.score < 900:#8
       background_image = background_image4
       if hud.level_number < 8:
            hud.level_number += 1
            pygame.mixer.music.load(resource_path("music/axe.mp3"))
            pygame.mixer.music.stop()
            pygame.mixer.music.play(-1)
       hud.lvlUp()
    if player_1.score > 900 and player_1.score < 1000:#9
       background_image = background_image5
       if hud.level_number < 9:
           hud.level_number += 1
           pygame.mixer.music.load(resource_path("music/boat.mp3"))
           pygame.mixer.music.stop()
           pygame.mixer.music.play(-1)
       hud.lvlUp()
    if player_1.score > 900 and player_1.score < 1000:#10
       background_image = background_image5
       if hud.level_number < 10:
           hud.level_number += 1
           pygame.mixer.music.load(resource_path("music/whale.mp3"))
           pygame.mixer.music.stop()
           pygame.mixer.music.play(-1)
       hud.lvlUp()
    if player_1.score > 1000 and player_1.score < 1100:#11
       background_image = background_image5
       if hud.level_number < 11:
           hud.level_number += 1
           pygame.mixer.music.load(resource_path("music/sneakysneak.mp3"))#sample rate == 44,100
           pygame.mixer.music.stop()
           pygame.mixer.music.play(-1)
       hud.lvlUp()

    if hud.level_number == 3 and enemy_spawn_timer > 80:
        enemy_spawn_timer = enemy_spawn_timer_max
    if hud.level_number == 5 and enemy_spawn_timer > 80:
        enemy_spawn_timer = enemy_spawn_timer_max
    if hud.level_number == 7 and enemy_spawn_timer > 80:
        enemy_spawn_timer = enemy_spawn_timer_max
    if hud.level_number == 9 and enemy_spawn_timer > 80:
        enemy_spawn_timer = enemy_spawn_timer_max
    if hud.level_number == 11 and enemy_spawn_timer > 80:
        enemy_spawn_timer = enemy_spawn_timer_max
            
    hud.update()
    # Tell pygame to update the screen
    pygame.display.flip()
    clock.tick(40)
    pygame.display.set_caption("ATTACK OF THE ZOMBIE BABIES fps: " + str(clock.get_fps()))

pygame.display.quit()






