import src/main

os.system("python src/main.py")
